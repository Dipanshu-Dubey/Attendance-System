<?php
// Start session
session_start();

// Include database connection
include '__dbconnection.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize
    $full_name = isset($_POST['full_name']) ? trim($_POST['full_name']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $role = isset($_POST['role']) ? $_POST['role'] : '';
    
    // Validate data
    $error = false;
    
    // Store current form data in session (except password)
    $_SESSION['form_data'] = [
        'full_name' => $full_name,
        'email' => $email,
        'role' => $role
    ];
    
    if (empty($full_name) || empty($email) || empty($password) || empty($role)) {
        $_SESSION['error'] = "All fields are required";
        $error = true;
    } elseif (strlen($password) < 6) {
        $_SESSION['error'] = "Password must be at least 6 characters long";
        $error = true;
    }
    
    // Validate password complexity
    $uppercase = preg_match('/[A-Z]/', $password);
    $lowercase = preg_match('/[a-z]/', $password);
    $number = preg_match('/[0-9]/', $password);
    $specialChars = preg_match('/[^A-Za-z0-9]/', $password);
    
    $strength = 0;
    if (strlen($password) >= 6) $strength++;
    if ($uppercase) $strength++;
    if ($lowercase) $strength++;
    if ($number) $strength++;
    if ($specialChars) $strength++;
    
    if ($strength < 3) {
        $_SESSION['error'] = "Password is too weak. It should include uppercase letters, numbers, or special characters.";
        $error = true;
    }
    
    // Check if email already exists
    if (!$error) {
        $sql = "SELECT id FROM employees WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $_SESSION['error'] = "Email already exists. Please use a different email.";
            $error = true;
        }
    }
    
    // If there's an error, redirect back to the signup form
    if ($error) {
        header("Location: index.php?action=register");
        exit;
    }
    
    // If validation passes, hash the password and insert the new user
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $sql = "INSERT INTO employees (name, email, password, role) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $full_name, $email, $hashed_password, $role);
    
    if ($stmt->execute()) {
        // Store data in session for use in capture_image.php
        $_SESSION['user_id'] = $conn->insert_id;
        $_SESSION['name'] = $full_name;
        $_SESSION['email'] = $email;
        $_SESSION['role'] = $role;
        
        // Clear form data from session since registration was successful
        unset($_SESSION['form_data']);
        
        // Redirect to face capture page
        header("Location: capture_image.php");
        exit;
    } else {
        $_SESSION['error'] = "Registration failed: " . $stmt->error;
        header("Location: index.php?action=register");
        exit;
    }
} else {
    // If accessed directly without POST data, redirect to main page
    header("Location: index.php");
    exit;
}
?> 