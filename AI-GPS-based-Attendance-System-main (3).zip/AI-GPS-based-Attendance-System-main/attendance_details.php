<?php
session_start();

// Include database connection
include '__dbconnection.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'Admin') {
    // Not logged in or not an admin, redirect to login page
    $_SESSION['error'] = "You must login as Admin to access this page";
    header("Location: index.php");
    exit;
}

// Get attendance records with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 15;
$offset = ($page - 1) * $records_per_page;

// Default date filter is today
$date_filter = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Get total records for pagination
$total_records_sql = "SELECT COUNT(*) as count FROM attendance WHERE DATE(timestamp) = ?";
$stmt = $conn->prepare($total_records_sql);
$stmt->bind_param("s", $date_filter);
$stmt->execute();
$result = $stmt->get_result();
$total_records = $result->fetch_assoc()['count'];
$total_pages = ceil($total_records / $records_per_page);

// Get attendance records
$sql = "SELECT a.*, e.name, e.email, e.face_image, e.location_id, l.name as location_name 
        FROM attendance a 
        JOIN employees e ON a.id = e.id 
        LEFT JOIN locations l ON e.location_id = l.id 
        WHERE DATE(a.timestamp) = ? 
        ORDER BY a.timestamp DESC 
        LIMIT ?, ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sii", $date_filter, $offset, $records_per_page);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Details - Face Attendance System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="static/modern-style.css">
    <script src="static/admin-menu.js" defer></script>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-user-shield"></i>
            <span>Admin Panel</span>
        </div>
        <ul class="sidebar-nav">
            <li class="sidebar-nav-item">
                <a href="admin_dashboard.php" class="sidebar-nav-link">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="employee_registration.php" class="sidebar-nav-link">
                    <i class="fas fa-user-plus"></i>
                    <span>Employee Registration</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="manage_employees.php" class="sidebar-nav-link">
                    <i class="fas fa-users"></i>
                    <span>Manage Employees</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="mark_attendance.php" class="sidebar-nav-link">
                    <i class="fas fa-calendar-check"></i>
                    <span>Mark Attendance</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="attendance_details.php" class="sidebar-nav-link active">
                    <i class="fas fa-list"></i>
                    <span>Attendance Details</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="settings.php" class="sidebar-nav-link">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="logout.php" class="sidebar-nav-link">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">Attendance Details</h1>
            <div class="d-flex align-items-center gap-3">
                <button class="dark-mode-toggle">
                    <i class="fas fa-moon"></i>
                </button>
                <div class="avatar">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=4C8BF5&color=fff" alt="Admin">
                </div>
            </div>
        </div>

        <!-- Date Filter -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label">Select Date</label>
                        <input type="date" class="form-control" name="date" value="<?php echo $date_filter; ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-2"></i>Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Attendance Records -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Attendance Records - <?php echo date('d M Y', strtotime($date_filter)); ?></h5>
                <button class="btn btn-outline-primary btn-sm" onclick="window.print()">
                    <i class="fas fa-print me-2"></i>Print
                </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>Email</th>
                                <th>Time</th>
                                <th>Status</th>
                                <th>Location</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <?php if($row['face_image']): ?>
                                                <img src="<?php echo $row['face_image']; ?>" 
                                                     alt="<?php echo $row['name']; ?>" 
                                                     class="rounded-circle" 
                                                     style="width: 32px; height: 32px; object-fit: cover;">
                                            <?php else: ?>
                                                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($row['name']); ?>&background=4C8BF5&color=fff" 
                                                     alt="<?php echo $row['name']; ?>" 
                                                     class="rounded-circle" 
                                                     style="width: 32px; height: 32px;">
                                            <?php endif; ?>
                                            <span><?php echo $row['name']; ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo $row['email']; ?></td>
                                    <td><?php echo date('h:i A', strtotime($row['timestamp'])); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo $row['status'] == 'Present' ? 'success' : 'danger'; ?>">
                                            <?php echo $row['status']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $row['location_name'] ?? 'N/A'; ?></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4">No attendance records found for this date</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <nav aria-label="Page navigation" class="mt-4">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?date=<?php echo $date_filter; ?>&page=<?php echo $page - 1; ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                        <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                            <a class="page-link" href="?date=<?php echo $date_filter; ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                        <?php endfor; ?>
                        <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?date=<?php echo $date_filter; ?>&page=<?php echo $page + 1; ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Dark mode toggle
        document.querySelector('.dark-mode-toggle').addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
        });
    </script>
</body>
</html> 