/**
 * Admin panel mobile menu and animations for EMP_ATTENDANCE System
 */

document.addEventListener('DOMContentLoaded', function() {
  // Create mobile menu toggle for admin pages
  createMobileMenuToggle();
  
  // Initialize card animations
  initializeCardAnimations();
  
  // Initialize dark mode toggle
  initializeDarkMode();
  
  // Initialize table responsive
  makeTablesResponsive();
});

// Create mobile menu toggle button for small screens
function createMobileMenuToggle() {
  // Check if we're on a page with sidebar
  const sidebar = document.querySelector('.sidebar');
  if (!sidebar) return;
  
  // Only create toggle on mobile screens
  if (window.innerWidth <= 576 && !document.querySelector('.mobile-menu-toggle')) {
    const menuToggle = document.createElement('button');
    menuToggle.className = 'mobile-menu-toggle';
    menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
    document.body.appendChild(menuToggle);
    
    menuToggle.addEventListener('click', function() {
      sidebar.classList.toggle('show');
      this.innerHTML = sidebar.classList.contains('show') 
        ? '<i class="fas fa-times"></i>' 
        : '<i class="fas fa-bars"></i>';
    });
  }
  
  // Close sidebar when clicking outside on mobile
  document.addEventListener('click', function(event) {
    if (
      window.innerWidth <= 576 && 
      sidebar.classList.contains('show') && 
      !sidebar.contains(event.target) && 
      !event.target.classList.contains('mobile-menu-toggle') &&
      !event.target.closest('.mobile-menu-toggle')
    ) {
      sidebar.classList.remove('show');
      const menuToggle = document.querySelector('.mobile-menu-toggle');
      if (menuToggle) {
        menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
      }
    }
  });
  
  // Update on window resize
  window.addEventListener('resize', function() {
    if (window.innerWidth > 576) {
      sidebar.classList.remove('show');
      const menuToggle = document.querySelector('.mobile-menu-toggle');
      if (menuToggle) {
        menuToggle.remove();
      }
    } else if (!document.querySelector('.mobile-menu-toggle')) {
      createMobileMenuToggle();
    }
  });
}

// Animate cards as they enter viewport
function initializeCardAnimations() {
  // Add 'visible' class to cards when they enter viewport
  const animateOnScroll = function() {
    const cards = document.querySelectorAll('.card:not(.visible)');
    cards.forEach((card, index) => {
      if (card.getBoundingClientRect().top < window.innerHeight * 0.9) {
        setTimeout(() => {
          card.classList.add('visible');
        }, index * 100); // Stagger the animations
      }
    });
  };
  
  // Run on load and scroll
  window.addEventListener('load', animateOnScroll);
  window.addEventListener('scroll', animateOnScroll);
}

// Initialize dark mode toggle
function initializeDarkMode() {
  const darkModeToggle = document.querySelector('.dark-mode-toggle');
  if (!darkModeToggle) return;
  
  // Check for stored preference
  const storedDarkMode = localStorage.getItem('dark-mode');
  if (storedDarkMode === 'true') {
    document.body.classList.add('dark-mode');
    darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
  } else {
    darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>';
  }
  
  // Toggle dark mode on click
  darkModeToggle.addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
    
    // Update icon
    if (document.body.classList.contains('dark-mode')) {
      this.innerHTML = '<i class="fas fa-sun"></i>';
    } else {
      this.innerHTML = '<i class="fas fa-moon"></i>';
    }
    
    // Store preference
    localStorage.setItem('dark-mode', document.body.classList.contains('dark-mode'));
  });
}

// Make tables responsive
function makeTablesResponsive() {
  const tables = document.querySelectorAll('table:not(.table-responsive)');
  tables.forEach(table => {
    // Wrap table in a div with table-responsive class if not already wrapped
    if (!table.parentElement.classList.contains('table-responsive')) {
      const wrapper = document.createElement('div');
      wrapper.className = 'table-responsive';
      table.parentNode.insertBefore(wrapper, table);
      wrapper.appendChild(table);
    }
  });
} 