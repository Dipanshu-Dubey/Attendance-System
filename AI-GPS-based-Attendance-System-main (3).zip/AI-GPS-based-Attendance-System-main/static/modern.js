/**
 * Modern.js - Enhanced JavaScript for EMP_ATTENDANCE System
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize animations
    initAnimations();
    
    // Initialize dark mode
    initDarkMode();
    
    // Initialize sidebar toggle
    initSidebar();
    
    // Initialize form validations
    initFormValidations();
    
    // Initialize alert dismissals
    initAlertDismissals();

    // Initialize dark mode from localStorage
    if (localStorage.getItem('dark-mode') === 'true') {
        document.body.classList.add('dark-mode');
    }

    // Dark mode toggle with animation and localStorage persistence
    const darkModeToggle = document.querySelector('.dark-mode-toggle');
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            // Save preference to localStorage
            localStorage.setItem('dark-mode', document.body.classList.contains('dark-mode'));
        });
    }

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Password confirmation validation
    const passwordField = document.getElementById('password');
    const confirmPasswordField = document.getElementById('confirm_password');
    
    if (passwordField && confirmPasswordField) {
        confirmPasswordField.addEventListener('input', function() {
            if (passwordField.value !== confirmPasswordField.value) {
                confirmPasswordField.setCustomValidity('Passwords do not match');
            } else {
                confirmPasswordField.setCustomValidity('');
            }
        });
        
        passwordField.addEventListener('input', function() {
            if (confirmPasswordField.value) {
                if (passwordField.value !== confirmPasswordField.value) {
                    confirmPasswordField.setCustomValidity('Passwords do not match');
                } else {
                    confirmPasswordField.setCustomValidity('');
                }
            }
        });
    }

    // Card animations on scroll
    const animateCards = function() {
        const cards = document.querySelectorAll('.card');
        cards.forEach(card => {
            const cardPosition = card.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.3;
            
            if (cardPosition < screenPosition) {
                card.classList.add('animated');
            }
        });
    };
    
    // Run on load
    animateCards();
    
    // Run on scroll
    window.addEventListener('scroll', animateCards);

    // Mobile responsiveness for sidebar
    const handleResponsiveSidebar = function() {
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        
        if (window.innerWidth <= 576 && sidebar) {
            // Add menu toggle button for mobile if it doesn't exist
            if (!document.querySelector('.menu-toggle')) {
                const menuToggle = document.createElement('button');
                menuToggle.className = 'menu-toggle btn btn-primary btn-sm position-fixed';
                menuToggle.style.cssText = 'top: 10px; left: 10px; z-index: 1100; padding: 0.3rem 0.6rem;';
                menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
                document.body.appendChild(menuToggle);
                
                menuToggle.addEventListener('click', function() {
                    sidebar.classList.toggle('show');
                });
            }
            
            // Adjust main content margin when sidebar is shown/hidden
            if (sidebar.classList.contains('show')) {
                mainContent.style.marginLeft = '200px';
            } else {
                mainContent.style.marginLeft = '0';
            }
        } else {
            // Remove menu toggle button on larger screens
            const menuToggle = document.querySelector('.menu-toggle');
            if (menuToggle) {
                menuToggle.remove();
            }
            
            // Reset main content margin on larger screens
            if (sidebar) {
                if (window.innerWidth <= 992) {
                    mainContent.style.marginLeft = '70px';
                } else {
                    mainContent.style.marginLeft = '260px';
                }
            }
        }
    };
    
    // Run on load and resize
    handleResponsiveSidebar();
    window.addEventListener('resize', handleResponsiveSidebar);

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const closeButton = alert.querySelector('.btn-close');
            if (closeButton) {
                closeButton.click();
            }
        }, 5000);
    });

    // Add smooth transitions when clicking links
    document.querySelectorAll('a:not([target="_blank"])').forEach(link => {
        link.addEventListener('click', function(e) {
            // Don't apply to links that open modals
            if (this.getAttribute('data-bs-toggle') === 'modal') return;
            
            const href = this.getAttribute('href');
            if (href && href.indexOf('#') !== 0 && href !== 'javascript:void(0)') {
                e.preventDefault();
                document.body.style.opacity = '0.5';
                document.body.style.transition = 'opacity 0.3s ease';
                setTimeout(() => {
                    window.location.href = href;
                }, 300);
            }
        });
    });
});

// ======== Animation Functions ========
function initAnimations() {
    // Card reveal animations
    const cards = document.querySelectorAll('.card');
    
    // Use IntersectionObserver to detect when cards enter viewport
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                setTimeout(() => {
                    entry.target.classList.add('visible');
                }, 100 * Array.from(cards).indexOf(entry.target));
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    
    cards.forEach(card => {
        observer.observe(card);
    });
}

// ======== Dark Mode Functions ========
function initDarkMode() {
    const darkModeToggle = document.querySelector('.dark-mode-toggle');
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    
    // Check for saved user preference
    const currentTheme = localStorage.getItem('theme');
    
    // If user has previously selected dark mode or prefers dark mode
    if (currentTheme === 'dark' || (currentTheme === null && prefersDarkScheme.matches)) {
        document.body.classList.add('dark-mode');
        updateDarkModeIcon(true);
    } else {
        updateDarkModeIcon(false);
    }
    
    // Add click event to toggle
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', function() {
            const isDarkMode = document.body.classList.toggle('dark-mode');
            updateDarkModeIcon(isDarkMode);
            
            // Save preference to localStorage
            localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
        });
    }
}

function updateDarkModeIcon(isDarkMode) {
    const darkModeToggle = document.querySelector('.dark-mode-toggle');
    if (darkModeToggle) {
        darkModeToggle.innerHTML = isDarkMode ? 
            '<i class="fas fa-sun"></i>' : 
            '<i class="fas fa-moon"></i>';
    }
}

// ======== Sidebar Functions ========
function initSidebar() {
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    
    if (sidebarToggle && sidebar) {
        // Check for saved sidebar state
        const sidebarState = localStorage.getItem('sidebar');
        
        if (sidebarState === 'collapsed') {
            sidebar.classList.add('sidebar-collapsed');
            if (mainContent) mainContent.classList.add('expanded');
        }
        
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('sidebar-collapsed');
            
            if (mainContent) {
                mainContent.classList.toggle('expanded');
            }
            
            // Save sidebar state
            localStorage.setItem('sidebar', 
                sidebar.classList.contains('sidebar-collapsed') ? 'collapsed' : 'expanded');
        });
        
        // Mobile detection
        const handleResize = () => {
            if (window.innerWidth <= 768) {
                sidebar.classList.add('sidebar-collapsed');
                if (mainContent) mainContent.classList.add('expanded');
            } else {
                if (localStorage.getItem('sidebar') !== 'collapsed') {
                    sidebar.classList.remove('sidebar-collapsed');
                    if (mainContent) mainContent.classList.remove('expanded');
                }
            }
        };
        
        // Initial check
        handleResize();
        
        // Listen for window resizing
        window.addEventListener('resize', handleResize);
    }
}

// ======== Form Validation Functions ========
function initFormValidations() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!validateForm(form)) {
                event.preventDefault();
            }
        });
        
        // Real-time validation
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(input);
            });
        });
    });
}

function validateForm(form) {
    let isValid = true;
    const inputs = form.querySelectorAll('input, select, textarea');
    
    inputs.forEach(input => {
        if (!validateField(input)) {
            isValid = false;
        }
    });
    
    // Password matching validation for registration forms
    const password = form.querySelector('input[name="password"]');
    const confirmPassword = form.querySelector('input[name="confirm_password"]');
    
    if (password && confirmPassword) {
        if (password.value !== confirmPassword.value) {
            showError(confirmPassword, 'Passwords do not match');
            isValid = false;
        }
    }
    
    return isValid;
}

function validateField(field) {
    clearError(field);
    
    // Required field validation
    if (field.hasAttribute('required') && !field.value.trim()) {
        showError(field, 'This field is required');
        return false;
    }
    
    // Email validation
    if (field.type === 'email' && field.value.trim()) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(field.value)) {
            showError(field, 'Please enter a valid email address');
            return false;
        }
    }
    
    // Password validation
    if (field.name === 'password' && field.value.trim()) {
        if (field.value.length < 6) {
            showError(field, 'Password must be at least 6 characters');
            return false;
        }
    }
    
    return true;
}

function showError(field, message) {
    // Clear any existing error
    clearError(field);
    
    // Create error message element
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    errorElement.style.color = '#C62828';
    errorElement.style.fontSize = '0.8rem';
    errorElement.style.marginTop = '5px';
    
    // Add error class to the input
    field.classList.add('error-input');
    field.style.borderColor = '#C62828';
    
    // Insert error message after the field
    field.parentNode.insertBefore(errorElement, field.nextSibling);
}

function clearError(field) {
    // Remove error class
    field.classList.remove('error-input');
    field.style.borderColor = '';
    
    // Remove error message if it exists
    const errorElement = field.nextElementSibling;
    if (errorElement && errorElement.className === 'error-message') {
        errorElement.remove();
    }
}

// ======== Alert Functions ========
function initAlertDismissals() {
    const alerts = document.querySelectorAll('.alert');
    
    alerts.forEach(alert => {
        // Add close button if not exists
        if (!alert.querySelector('.close')) {
            const closeButton = document.createElement('button');
            closeButton.className = 'close';
            closeButton.innerHTML = '&times;';
            closeButton.style.float = 'right';
            closeButton.style.border = 'none';
            closeButton.style.background = 'none';
            closeButton.style.fontSize = '1.25rem';
            closeButton.style.cursor = 'pointer';
            closeButton.style.padding = '0';
            closeButton.style.marginLeft = '15px';
            
            alert.classList.add('alert-dismissible');
            alert.prepend(closeButton);
        }
        
        // Add click event to close button
        const closeButton = alert.querySelector('.close');
        if (closeButton) {
            closeButton.addEventListener('click', function() {
                alert.style.opacity = '0';
                setTimeout(() => {
                    alert.style.display = 'none';
                }, 500);
            });
        }
        
        // Auto-hide alerts after 5 seconds
        if (!alert.classList.contains('alert-persistent')) {
            setTimeout(() => {
                alert.style.opacity = '0';
                setTimeout(() => {
                    alert.style.display = 'none';
                }, 500);
            }, 5000);
        }
    });
}

// ======== Webcam Functions ========
function initWebcam(videoElement, canvasElement, captureButton, retakeButton, saveButton, inputElement) {
    let stream = null;
    
    // Access the webcam
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(function(videoStream) {
            stream = videoStream;
            videoElement.srcObject = stream;
            videoElement.play();
            videoElement.style.display = 'block';
            captureButton.style.display = 'block';
            retakeButton.style.display = 'none';
            saveButton.style.display = 'none';
        })
        .catch(function(error) {
            console.error('Error accessing webcam:', error);
            alert('Error accessing webcam. Please ensure your camera is connected and permissions are granted.');
        });
    
    // Capture image
    captureButton.addEventListener('click', function() {
        const context = canvasElement.getContext('2d');
        context.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);
        
        // Stop the video stream
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
        
        // Show/hide appropriate buttons
        videoElement.style.display = 'none';
        canvasElement.style.display = 'block';
        captureButton.style.display = 'none';
        retakeButton.style.display = 'block';
        saveButton.style.display = 'block';
        
        // Convert canvas to base64 and set as value for the hidden input
        const imageData = canvasElement.toDataURL('image/png');
        inputElement.value = imageData;
    });
    
    // Retake photo
    retakeButton.addEventListener('click', function() {
        // Access the webcam again
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(videoStream) {
                stream = videoStream;
                videoElement.srcObject = stream;
                videoElement.play();
                
                // Show/hide appropriate elements
                videoElement.style.display = 'block';
                canvasElement.style.display = 'none';
                captureButton.style.display = 'block';
                retakeButton.style.display = 'none';
                saveButton.style.display = 'none';
                
                // Clear the input value
                inputElement.value = '';
            })
            .catch(function(error) {
                console.error('Error accessing webcam:', error);
                alert('Error accessing webcam. Please ensure your camera is connected and permissions are granted.');
            });
    });
}

// ======== Utility Functions ========
function formatDate(date) {
    const d = new Date(date);
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const year = d.getFullYear();
    return `${year}-${month}-${day}`;
}

function formatTime(time) {
    const t = new Date(time);
    const hours = String(t.getHours()).padStart(2, '0');
    const minutes = String(t.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
}

// Add dark mode toggle button if it doesn't exist
function ensureDarkModeToggle() {
    if (!document.querySelector('.dark-mode-toggle')) {
        const toggle = document.createElement('button');
        toggle.className = 'dark-mode-toggle';
        toggle.innerHTML = '<i class="fas fa-moon"></i>';
        document.body.appendChild(toggle);
        
        // Initialize dark mode
        initDarkMode();
    }
} 