<?php
// Start session at the very beginning of the file
session_start();

// Check if user is already logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    // Redirect based on role
    if ($_SESSION['role'] === 'Admin') {
        header("Location: admin_dashboard.php");
        exit;
    } else if ($_SESSION['role'] === 'Employee') {
        header("Location: employee_dashboard.php");
        exit;
    }
}

// Check if this is direct access to index.php without any action
// If yes, redirect to landing page
if (!isset($_GET['action']) && !isset($_POST['login']) && !isset($_POST['register'])) {
    header("Location: landing_page.php");
    exit;
}

// Store target parameter in session if provided
if (isset($_GET['target'])) {
    $_SESSION['target'] = $_GET['target'];
}

// Get form data from session if it exists, then clear it
$form_data = isset($_SESSION['form_data']) ? $_SESSION['form_data'] : [];

// Debug: Output the form data to see if it's available
// echo '<pre>' . print_r($form_data, true) . '</pre>'; // Uncomment for debugging

unset($_SESSION['form_data']);

// Otherwise, continue with the login/register page
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Attendance System</title>
    <link rel="stylesheet" href="static/app-styles.css">
    <link rel="stylesheet" href="static/modern-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Add modern JavaScript files -->
    <script src="static/modern.js" defer></script>
    <script src="static/mobile-menu.js" defer></script>
    <style>
        :root {
            --primary-color: #4C8BF5;
            --primary-hover: #3B73CC;
            --secondary-color: #3B73CC;
            --accent-color: #4C8BF5;
            --text-dark: #1C1C1C;
            --text-medium: #666666;
            --text-light: #AAAAAA;
            --bg-white: #ffffff;
            --bg-light: #F5F7FF;
            --bg-dark: #1C1C1C;
            --danger: #F555F5;
            --warning: #F555F5;
            --success: #4C8BF5;
            --border-color: #CCCCCC;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --radius-sm: 0.25rem;
            --radius: 0.5rem;
            --radius-lg: 1rem;
            --radius-full: 9999px;
            --header-height: 70px;
            --gradient-primary: linear-gradient(135deg, #4C8BF5, #3B73CC);
            --gradient-success: linear-gradient(135deg, #4C8BF5, #3B73CC);
            --gradient-danger: linear-gradient(135deg, #F555F5, #CF4DCF);
            --gradient-warning: linear-gradient(135deg, #F555F5, #CF4DCF);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: var(--bg-light);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .app-header {
            height: var(--header-height);
            background: var(--bg-white);
            box-shadow: var(--shadow-sm);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 2rem;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 100;
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logo-icon {
            width: 2.5rem;
            height: 2.5rem;
            background: var(--gradient-primary);
            border-radius: var(--radius-full);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.25rem;
        }

        .nav-links {
            display: flex;
            gap: 1.5rem;
        }

        .nav-link {
            color: var(--text-medium);
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
            transition: color 0.2s;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }

        .nav-link:hover {
            color: var(--primary-color);
        }

        .nav-link.active {
            color: var(--primary-color);
        }

        .auth-container {
            padding-top: var(--header-height);
            min-height: 100vh;
            display: flex;
            width: 100%;
        }

        .auth-image {
            flex: 1.2;
            background: var(--gradient-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            padding: 2rem;
            position: relative;
            overflow: hidden;
        }

        .auth-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB4PSIwIiB5PSIwIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSgzMCkiPjxyZWN0IHg9IjAiIHk9IjAiIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSI+PC9yZWN0PjwvcGF0dGVybj48L2RlZnM+PHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNwYXR0ZXJuKSI+PC9yZWN0Pjwvc3ZnPg==');
            opacity: 0.8;
        }

        .auth-content {
            z-index: 10;
            max-width: 500px;
            text-align: center;
        }

        .auth-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .auth-subtitle {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .auth-features {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            text-align: left;
            margin-top: 2rem;
        }

        .feature {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .feature-icon {
            width: 2.5rem;
            height: 2.5rem;
            background: rgba(255, 255, 255, 0.2);
            border-radius: var(--radius-full);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
        }

        .feature-text {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .auth-form {
            flex: 0.8;
            padding: 3rem 4rem;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background-color: var(--bg-white);
        }

        .form-header {
            margin-bottom: 2rem;
            text-align: center;
        }

        .form-title {
            font-size: 1.75rem;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .form-subtitle {
            font-size: 0.9rem;
            color: var(--text-medium);
        }

        .tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            border-bottom: 1px solid var(--border-color);
        }

        .tab {
            padding: 0.75rem 1rem;
            font-weight: 500;
            color: var(--text-medium);
            cursor: pointer;
            position: relative;
            transition: color 0.2s;
        }

        .tab:hover {
            color: var(--primary-color);
        }

        .tab.active {
            color: var(--primary-color);
        }

        .tab.active::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            width: 100%;
            height: 2px;
            background: var(--gradient-primary);
        }

        .form-container {
            display: none;
        }

        .form-container.active {
            display: block;
            animation: fadeIn 0.5s ease forwards;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .form-control {
            display: block;
            width: 100%;
            padding: 0.75rem 1rem;
            font-size: 1rem;
            line-height: 1.5;
            color: var(--text-dark);
            background-color: white !important;
            background-clip: padding-box;
            border: 1px solid #e0e5f0;
            border-radius: var(--radius);
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            outline: 0;
            box-shadow: 0 0 0 3px rgba(76, 139, 245, 0.15);
            background-color: white !important;
        }

        /* Specific styles for select elements */
        select.form-control {
            background-color: white !important;
            color: var(--text-dark);
        }
        
        select.form-control option {
            background-color: white;
            color: var(--text-dark);
        }

        .input-group {
            position: relative;
        }

        .input-group .form-control {
            padding-left: 3rem;
        }

        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--primary-color);
        }

        .btn {
            display: inline-block;
            font-weight: 500;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            user-select: none;
            border: none;
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
            line-height: 1.5;
            border-radius: var(--radius);
            transition: all 0.2s;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,0.2) 100%);
            transform: translateX(-100%);
            transition: transform 0.6s;
        }

        .btn:hover::before {
            transform: translateX(100%);
        }

        .btn-primary {
            background: var(--gradient-primary);
            color: white;
        }

        .btn-primary:hover {
            box-shadow: 0 4px 12px rgba(58, 123, 213, 0.3);
            transform: translateY(-2px);
        }

        .btn-lg {
            padding: 1rem 2rem;
            font-size: 1.125rem;
            border-radius: var(--radius);
        }

        .btn-block {
            display: block;
            width: 100%;
        }

        .divider {
            display: flex;
            align-items: center;
            color: var(--text-light);
            font-size: 0.875rem;
            margin: 1.5rem 0;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background-color: var(--border-color);
        }

        .divider::before {
            margin-right: 1rem;
        }

        .divider::after {
            margin-left: 1rem;
        }

        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: var(--radius);
            font-size: 0.9rem;
            position: relative;
            overflow: hidden;
        }

        .alert::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 4px;
        }

        .alert-success {
            color: #10b981;
            background-color: rgba(56, 239, 125, 0.1);
            border: none;
        }

        .alert-success::before {
            background: var(--gradient-success);
        }

        .alert-danger {
            color: #f43f5e;
            background-color: rgba(245, 54, 92, 0.1);
            border: none;
        }

        .alert-danger::before {
            background: var(--gradient-danger);
        }

        /* Animation for initial load */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.5s ease-out forwards;
        }

        /* Responsive styles */
        @media (max-width: 992px) {
            .auth-container {
                flex-direction: column;
            }
            .auth-image {
                min-height: 300px;
            }
            .auth-form {
                padding: 2rem;
            }
        }

        @media (max-width: 768px) {
            .app-header {
                padding: 0 1.5rem;
            }
            .auth-form {
                padding: 1.5rem;
            }
            .auth-image {
                min-height: 250px;
            }
        }

        @media (max-width: 576px) {
            .app-header {
                padding: 0 1rem;
            }
            .logo-text {
                display: none;
            }
            .nav-link span {
                display: none;
            }
            .auth-form {
                padding: 1.25rem;
            }
            .tabs {
                gap: 0;
            }
            .tab {
                flex: 1;
                text-align: center;
                padding: 0.75rem 0;
            }
            .auth-image {
                min-height: 200px;
            }
        }

        #signupForm .form-control {
            background-color: #f5f8ff;
            border: 1px solid #e0e5f0;
            color: var(--text-dark);
        }
        
        #signupForm .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(76, 139, 245, 0.15);
            background-color: white;
        }
        
        #signupForm .input-icon {
            color: var(--primary-color);
        }

        /* Password validation styles */
        .form-control.is-invalid {
            border-color: #f43f5e;
            background-color: rgba(244, 63, 94, 0.05);
        }
        
        .form-control.is-valid {
            border-color: #10b981;
            background-color: rgba(16, 185, 129, 0.05);
        }
        
        .validation-message {
            font-size: 0.8rem;
            margin-top: 0.25rem;
            display: none;
        }
        
        .validation-message.error {
            color: #f43f5e;
            display: block;
        }
        
        .validation-message.success {
            color: #10b981;
            display: block;
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="logo-container">
            <div class="logo">
                <div class="logo-icon">
                    <i class="fas fa-id-card"></i>
                </div>
                <span class="logo-text">AttendX</span>
            </div>
        </div>
        <nav class="nav-links">
            <a href="#" class="nav-link active">
                <i class="fas fa-info-circle"></i>
                <span>About</span>
            </a>
            <a href="#" class="nav-link">
                <i class="fas fa-question-circle"></i>
                <span>Help</span>
            </a>
        </nav>
    </header>

    <main class="auth-container">
        <div class="auth-image">
            <div class="auth-overlay"></div>
            <div class="auth-content">
                <h1 class="auth-title">Employee Attendance System</h1>
                <p class="auth-subtitle">A comprehensive solution for managing employee attendance, time tracking, and productivity monitoring.</p>
                
                <div class="auth-features">
                    <div class="feature">
                        <div class="feature-icon">
                            <i class="fas fa-camera"></i>
                        </div>
                        <div>
                            <h3>Face Recognition</h3>
                            <p class="feature-text">Secure authentication using advanced facial recognition technology.</p>
                        </div>
                    </div>
                    <div class="feature">
                        <div class="feature-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div>
                            <h3>Real-time Tracking</h3>
                            <p class="feature-text">Monitor attendance and time records in real-time with accurate timestamps.</p>
                        </div>
                    </div>
                    <div class="feature">
                        <div class="feature-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div>
                            <h3>Detailed Analytics</h3>
                            <p class="feature-text">Generate comprehensive reports and analytics on attendance patterns.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="auth-form">
            <div class="form-header">
                <h2 class="form-title">Welcome Back</h2>
                <p class="form-subtitle">Sign in to continue to your dashboard</p>
            </div>
            
            <div id="message-container">
                <?php
                // Display error message if exists
                if (isset($_SESSION['error'])) {
                    echo '<div class="alert alert-danger">';
                    echo '<i class="fas fa-exclamation-circle"></i> ' . $_SESSION['error'];
                    echo '</div>';
                    unset($_SESSION['error']); // Clear the error message
                }
                
                // Display success message if exists
                if (isset($_SESSION['success'])) {
                    echo '<div class="alert alert-success">';
                    echo '<i class="fas fa-check-circle"></i> ' . $_SESSION['success'];
                    echo '</div>';
                    unset($_SESSION['success']); // Clear the success message
                }
                ?>
            </div>
            
            <div class="tabs">
                <div class="tab <?php echo (!isset($_GET['action']) || $_GET['action'] === 'login') ? 'active' : ''; ?>" data-tab="login">Login</div>
                <div class="tab <?php echo (isset($_GET['action']) && $_GET['action'] === 'register') ? 'active' : ''; ?>" data-tab="register">Sign Up</div>
            </div>
            
            <div id="login-form" class="form-container <?php echo (!isset($_GET['action']) || $_GET['action'] === 'login') ? 'active' : ''; ?>">
                <form action="login_process.php" method="post" id="loginFormElement">
                    <div class="form-group">
                        <label for="email" class="form-label">Email Address</label>
                        <div class="input-group">
                            <i class="fas fa-envelope input-icon"></i>
                            <input type="email" id="email" name="email" class="form-control" placeholder="you@example.com" 
                                value="<?php 
                                    if(isset($form_data['email'])) {
                                        echo htmlspecialchars($form_data['email']);
                                    } elseif(isset($_POST['email'])) {
                                        echo htmlspecialchars($_POST['email']);
                                    }
                                ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <i class="fas fa-lock input-icon"></i>
                            <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required>
                        </div>
                    </div>
                    
                    <div class="form-group" style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <input type="checkbox" id="remember" name="remember" <?php 
                                if(isset($form_data['remember']) && $form_data['remember']) {
                                    echo 'checked';
                                } elseif(isset($_POST['remember'])) {
                                    echo 'checked';
                                }
                            ?>>
                            <label for="remember" style="font-size: 0.875rem; color: var(--text-medium);">Remember me</label>
                        </div>
                        <a href="#" style="font-size: 0.875rem; color: var(--primary-color); text-decoration: none;">Forgot password?</a>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="login" class="btn btn-primary btn-block">Sign In</button>
                    </div>
                </form>
                
                <div class="text-center mt-4">
                    <p style="font-size: 0.875rem; color: var(--text-medium);">
                        Don't have an account? 
                        <a href="#" id="goToRegister" style="color: var(--primary-color); text-decoration: none; font-weight: 500;">
                            Create one now
                        </a>
                    </p>
                </div>
            </div>
            
            <div id="register-form" class="form-container <?php echo (isset($_GET['action']) && $_GET['action'] === 'register') ? 'active' : ''; ?>">
                <form action="signup_process.php" method="post" id="registerFormElement">
                    <div class="form-group">
                        <label for="full_name" class="form-label">Full Name</label>
                        <div class="input-group">
                            <i class="fas fa-user input-icon"></i>
                            <input type="text" id="full_name" name="full_name" class="form-control" placeholder="John Doe" 
                                value="<?php 
                                    if(isset($form_data['full_name'])) {
                                        echo htmlspecialchars($form_data['full_name']);
                                    } elseif(isset($_POST['full_name'])) {
                                        echo htmlspecialchars($_POST['full_name']);
                                    }
                                ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="reg_email" class="form-label">Email Address</label>
                        <div class="input-group">
                            <i class="fas fa-envelope input-icon"></i>
                            <input type="email" id="reg_email" name="email" class="form-control" placeholder="you@example.com" 
                                value="<?php 
                                    if(isset($form_data['email'])) {
                                        echo htmlspecialchars($form_data['email']);
                                    } elseif(isset($_POST['email'])) {
                                        echo htmlspecialchars($_POST['email']);
                                    }
                                ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="reg_password" class="form-label">Password</label>
                        <div class="input-group">
                            <i class="fas fa-lock input-icon"></i>
                            <input type="password" id="reg_password" name="password" class="form-control" placeholder="••••••••" required>
                        </div>
                        <small id="password-requirements" class="form-text text-muted">Password must be at least 6 characters long</small>
                        <div id="password-length-message" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label for="register_role" class="form-label">Select Role</label>
                        <div class="input-group">
                            <i class="fas fa-user-shield input-icon"></i>
                            <select id="register_role" name="role" class="form-control" required>
                                <option value="" disabled>Select your role</option>
                                <option value="Admin" <?php 
                                    if(isset($form_data['role']) && $form_data['role'] == 'Admin') {
                                        echo 'selected';
                                    } elseif(isset($_POST['role']) && $_POST['role'] == 'Admin') {
                                        echo 'selected';
                                    }
                                ?>>Admin</option>
                                <option value="Employee" <?php 
                                    if(isset($form_data['role']) && $form_data['role'] == 'Employee') {
                                        echo 'selected';
                                    } elseif(isset($_POST['role']) && $_POST['role'] == 'Employee') {
                                        echo 'selected';
                                    }
                                ?>>Employee</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="register" class="btn btn-primary btn-block">Register & Continue</button>
                    </div>
                </form>
                
                <div class="text-center mt-4">
                    <p style="font-size: 0.875rem; color: var(--text-medium);">
                        Already have an account? 
                        <a href="#" id="goToLogin" style="color: var(--primary-color); text-decoration: none; font-weight: 500;">
                            Sign in
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Tab switching functionality
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('.tab');
            const goToRegisterLink = document.getElementById('goToRegister');
            const goToLoginLink = document.getElementById('goToLogin');
            const registerForm = document.getElementById('registerFormElement');
            
            // Navigate between forms using links
            goToRegisterLink.addEventListener('click', function(e) {
                e.preventDefault();
                activateTab('register');
            });
            
            goToLoginLink.addEventListener('click', function(e) {
                e.preventDefault();
                activateTab('login');
            });
            
            // Password confirmation check for registration form
            if (registerForm) {
                registerForm.addEventListener('submit', function(e) {
                    const role = document.getElementById('register_role').value;
                    if (!role) {
                        alert('Please select a role to continue.');
                        e.preventDefault();
                        return false;
                    }
                    
                    // Form will submit normally if validations pass
                    return true;
                });
            }
            
            function activateTab(tabName) {
                // Update tabs
                tabs.forEach(t => {
                    if(t.getAttribute('data-tab') === tabName) {
                        t.classList.add('active');
                    } else {
                        t.classList.remove('active');
                    }
                });
                
                // Update form containers
                document.querySelectorAll('.form-container').forEach(form => {
                    form.classList.remove('active');
                });
                document.getElementById(tabName + '-form').classList.add('active');
                
                // Update form header
                const formTitle = document.querySelector('.form-title');
                const formSubtitle = document.querySelector('.form-subtitle');
                
                if (tabName === 'login') {
                    formTitle.textContent = 'Welcome Back';
                    formSubtitle.textContent = 'Sign in to continue to your dashboard';
                } else {
                    formTitle.textContent = 'Create an Account';
                    formSubtitle.textContent = 'Join us to start managing attendance';
                }
            }
            
            tabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    activateTab(this.getAttribute('data-tab'));
                });
            });
        });
        
        // Real-time password validation
        document.addEventListener('DOMContentLoaded', function() {
            const passwordInput = document.getElementById('reg_password');
            const confirmInput = document.getElementById('confirm_password');
            const lengthMessage = document.getElementById('password-length-message');
            
            if (passwordInput) {
                // Check password length and complexity
                passwordInput.addEventListener('input', function() {
                    const password = this.value;
                    
                    // Initialize validation flags
                    let isLongEnough = password.length >= 6;
                    let hasUpperCase = /[A-Z]/.test(password);
                    let hasLowerCase = /[a-z]/.test(password);
                    let hasNumbers = /[0-9]/.test(password);
                    let hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password);
                    
                    // Calculate strength
                    let strength = 0;
                    if (isLongEnough) strength++;
                    if (hasUpperCase) strength++;
                    if (hasLowerCase) strength++;
                    if (hasNumbers) strength++;
                    if (hasSpecialChar) strength++;
                    
                    // Update UI based on password strength
                    if (password.length === 0) {
                        lengthMessage.textContent = '';
                        lengthMessage.className = 'validation-message';
                        this.classList.remove('is-valid', 'is-invalid');
                    } else if (password.length < 6) {
                        this.classList.add('is-invalid');
                        this.classList.remove('is-valid');
                        lengthMessage.textContent = 'Password must be at least 6 characters long';
                        lengthMessage.classList.add('error');
                        lengthMessage.classList.remove('success');
                    } else if (strength < 3) {
                        this.classList.add('is-invalid');
                        this.classList.remove('is-valid');
                        lengthMessage.textContent = 'Weak password. Add uppercase, numbers, or special characters.';
                        lengthMessage.classList.add('error');
                        lengthMessage.classList.remove('success');
                    } else {
                        this.classList.add('is-valid');
                        this.classList.remove('is-invalid');
                        lengthMessage.textContent = strength === 5 ? 'Strong password!' : 'Password strength is acceptable';
                        lengthMessage.classList.add('success');
                        lengthMessage.classList.remove('error');
                    }
                });
                
                // Initial validation if fields already have values (e.g., after page reload)
                if (passwordInput.value.length > 0) {
                    const event = new Event('input');
                    passwordInput.dispatchEvent(event);
                }
            }
        });
    </script>
</body>
</html>
