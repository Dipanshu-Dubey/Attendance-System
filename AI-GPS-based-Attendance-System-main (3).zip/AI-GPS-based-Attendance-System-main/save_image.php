<?php
// Start session
session_start();

// Include database connection
include '__dbconnection.php';

// Check if user registration data exists in session
if (!isset($_SESSION['user_id'])) {
    // If no session data, redirect to registration page
    $_SESSION['error'] = "Registration session expired. Please try again.";
    header("Location: index.php");
    exit;
}

// Check if the form was submitted via POST with image data
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['image_data'])) {
    // Get image data
    $image_data = $_POST['image_data'];
    
    // Get redirect URL if provided
    $redirect_url = isset($_POST['redirect_url']) ? $_POST['redirect_url'] : '';
    
    // Check if we should open in a new tab
    $open_new_tab = isset($_POST['open_new_tab']) && $_POST['open_new_tab'] === 'true';
    
    // Get user data from session
    $user_id = $_SESSION['user_id'];
    $full_name = $_SESSION['name'];
    $email = $_SESSION['email'];
    $role = $_SESSION['role'];
    
    // Process image data (remove the Data URL prefix)
    $image_data = str_replace('data:image/png;base64,', '', $image_data);
    $image_data = str_replace(' ', '+', $image_data);
    $image_binary = base64_decode($image_data);
    
    // Create images directory if it doesn't exist
    $upload_dir = 'uploads/faces/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Generate unique filename for the image
    $image_filename = 'face_' . time() . '_' . md5($email) . '.png';
    $image_path = $upload_dir . $image_filename;
    
    // Save image to file
    $file_saved = file_put_contents($image_path, $image_binary);
    
    if (!$file_saved) {
        $_SESSION['error'] = "Failed to save image. Please try again.";
        header("Location: index.php");
        exit;
    }
    
    try {
        // Update existing user record with face image
        $update_sql = "UPDATE employees SET face_image = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("si", $image_path, $user_id);
        $update_stmt->execute();
        
        // Set success message
        $_SESSION['success'] = "Face image saved successfully! You can now login with your credentials.";
        
        // If we need to open in a new tab and have a redirect URL, use JavaScript
        if ($open_new_tab && !empty($redirect_url)) {
            // Append the email as a query parameter to the redirect URL
            $redirect_url_with_email = $redirect_url . "?email=" . urlencode($email);
            
            // Output HTML with JavaScript to open a new tab and then redirect current page
            echo "<!DOCTYPE html>
                <html>
                <head>
                    <title>Face Scanning</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            text-align: center;
                            margin-top: 100px;
                            background-color: #f8f9fa;
                        }
                        .scanning-container {
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 30px;
                            background-color: white;
                            border-radius: 10px;
                            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
                        }
                        .scanning-icon {
                            color: #4f46e5;
                            font-size: 48px;
                            margin-bottom: 20px;
                            animation: pulse 1.5s infinite;
                        }
                        @keyframes pulse {
                            0% { transform: scale(1); opacity: 1; }
                            50% { transform: scale(1.1); opacity: 0.8; }
                            100% { transform: scale(1); opacity: 1; }
                        }
                        h1 {
                            color: #333;
                            margin-bottom: 20px;
                        }
                        p {
                            color: #666;
                            line-height: 1.6;
                            margin-bottom: 15px;
                        }
                        .progress-bar {
                            width: 100%;
                            height: 10px;
                            background-color: #e9ecef;
                            border-radius: 5px;
                            margin: 20px 0;
                            overflow: hidden;
                        }
                        .progress {
                            height: 100%;
                            background: linear-gradient(135deg, #4f46e5, #10b981);
                            width: 0%;
                            border-radius: 5px;
                            animation: progress 2s forwards;
                        }
                        @keyframes progress {
                            0% { width: 0%; }
                            100% { width: 100%; }
                        }
                    </style>
                    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css\">
                </head>
                <body>
                    <div class=\"scanning-container\">
                        <div class=\"scanning-icon\">
                            <i class=\"fas fa-camera\"></i>
                        </div>
                        <h1>Your Face is Being Scanned</h1>
                        <p>Please wait while we process your facial data for secure authentication.</p>
                        <div class=\"progress-bar\">
                            <div class=\"progress\"></div>
                        </div>
                        <p>Redirecting to face capture system...</p>
                    </div>
                    
                    <script>
                        // Open the face capture app immediately
                        window.onload = function() {
                            // Redirect to the face capture app
                            window.location.href = '" . $redirect_url_with_email . "';
                        };
                    </script>
                </body>
                </html>";
            exit;
        } else if (!empty($redirect_url)) {
            // Show face scanning message and then redirect to the URL
            echo "<!DOCTYPE html>
                <html>
                <head>
                    <title>Face Scanning</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            text-align: center;
                            margin-top: 100px;
                            background-color: #f8f9fa;
                        }
                        .scanning-container {
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 30px;
                            background-color: white;
                            border-radius: 10px;
                            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
                        }
                        .scanning-icon {
                            color: #4f46e5;
                            font-size: 48px;
                            margin-bottom: 20px;
                            animation: pulse 1.5s infinite;
                        }
                        @keyframes pulse {
                            0% { transform: scale(1); opacity: 1; }
                            50% { transform: scale(1.1); opacity: 0.8; }
                            100% { transform: scale(1); opacity: 1; }
                        }
                        h1 {
                            color: #333;
                            margin-bottom: 20px;
                        }
                        p {
                            color: #666;
                            line-height: 1.6;
                            margin-bottom: 15px;
                        }
                        .progress-bar {
                            width: 100%;
                            height: 10px;
                            background-color: #e9ecef;
                            border-radius: 5px;
                            margin: 20px 0;
                            overflow: hidden;
                        }
                        .progress {
                            height: 100%;
                            background: linear-gradient(135deg, #4f46e5, #10b981);
                            width: 0%;
                            border-radius: 5px;
                            animation: progress 2s forwards;
                        }
                        @keyframes progress {
                            0% { width: 0%; }
                            100% { width: 100%; }
                        }
                    </style>
                    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css\">
                </head>
                <body>
                    <div class=\"scanning-container\">
                        <div class=\"scanning-icon\">
                            <i class=\"fas fa-camera\"></i>
                        </div>
                        <h1>Your Face is Being Scanned</h1>
                        <p>Please wait while we process your facial data for secure authentication.</p>
                        <div class=\"progress-bar\">
                            <div class=\"progress\"></div>
                        </div>
                        <p>Redirecting to face capture system...</p>
                    </div>
                    
                    <script>
                        // Redirect after a short delay to show the animation
                        setTimeout(function() {
                            window.location.href = '" . $redirect_url_with_email . "';
                        }, 1500); // 1.5 seconds delay for the animation to play
                    </script>
                </body>
                </html>";
            exit;
        } else {
            // No redirect URL provided, go back to index
            header("Location: index.php");
            exit;
        }
    } catch (Exception $e) {
        // Remove image file if database update failed
        if (file_exists($image_path)) {
            unlink($image_path);
        }
        
        // Set error message
        $_SESSION['error'] = "Failed to save face image: " . $e->getMessage();
        
        // Redirect back to registration page
        header("Location: index.php");
        exit;
    }
} else {
    // If not a POST request or no image data, redirect to registration page
    $_SESSION['error'] = "No image data received. Please try again.";
    header("Location: index.php");
    exit;
}
?> 