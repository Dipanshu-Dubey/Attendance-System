<?php
// Start session
session_start();

// Include database connection
include '__dbconnection.php';

// Check if the form was submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    // Validate data
    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "Email and password are required";
        // Store form data in session
        $_SESSION['form_data'] = [
            'email' => $email,
            'remember' => isset($_POST['remember']) ? true : false
        ];
        header("Location: index.php?action=login");
        exit;
    }
    
    // Prepare SQL statement to prevent SQL injection
    $sql = "SELECT * FROM employees WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // For debugging - log user data
        error_log("User found: " . print_r($user, true));
        
        // Verify password (assuming you're using password_hash for storage)
        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['logged_in'] = true;
            
            // Log role for debugging
            error_log("User role: " . $user['role']);
            
            // Redirect based on role from database
            if ($user['role'] == 'Admin') {
                error_log("Redirecting to admin dashboard");
                
                // Check if there's a specific target to redirect to
                if (isset($_SESSION['target'])) {
                    $target = $_SESSION['target'];
                    unset($_SESSION['target']); // Clear the target
                    
                    switch($target) {
                        case 'attendance':
                            header("Location: mark_attendance.php");
                            break;
                        case 'records':
                            header("Location: attendance_details.php");
                            break;
                        default:
                            header("Location: admin_dashboard.php");
                    }
                } else {
                    header("Location: admin_dashboard.php");
                }
                exit;
            } else if ($user['role'] == 'Employee') {
                error_log("Redirecting to employee dashboard");
                
                // Check if there's a specific target to redirect to
                if (isset($_SESSION['target'])) {
                    $target = $_SESSION['target'];
                    unset($_SESSION['target']); // Clear the target
                    
                    switch($target) {
                        case 'attendance':
                            header("Location: check_in.php");
                            break;
                        case 'records':
                            header("Location: my_attendance.php");
                            break;
                        default:
                            header("Location: employee_dashboard.php");
                    }
                } else {
                    // Use absolute URL to ensure proper redirection
                    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                    $redirect_url = $base_url . "/EMP_ATTENDANCE/employee_dashboard.php";
                    error_log("Redirect URL: " . $redirect_url);
                    header("Location: " . $redirect_url);
                }
                exit;
            } else {
                // Handle unknown role type
                $_SESSION['error'] = "Invalid role type";
                header("Location: index.php?action=login");
                exit;
            }
        } else {
            $_SESSION['error'] = "Incorrect password";
            $_SESSION['form_data'] = [
                'email' => $email,
                'remember' => isset($_POST['remember']) ? true : false
            ];
            header("Location: index.php?action=login");
            exit;
        }
    } else {
        $_SESSION['error'] = "User not found";
        $_SESSION['form_data'] = [
            'email' => $email,
            'remember' => isset($_POST['remember']) ? true : false
        ];
        header("Location: index.php?action=login");
        exit;
    }
} else {
    // If not a POST request, redirect to login page
    header("Location: index.php?action=login");
    exit;
}
?>