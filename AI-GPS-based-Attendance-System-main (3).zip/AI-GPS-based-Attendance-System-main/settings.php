<?php
session_start();

// Include database connection
include '__dbconnection.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'Admin') {
    // Not logged in or not an admin, redirect to login page
    $_SESSION['error'] = "You must login as Admin to access this page";
    header("Location: index.php");
    exit;
}

// Define default settings if they don't exist
$default_settings = [
    'system_name' => 'Face Attendance System',
    'company_name' => 'Your Company Name',
    'enable_face_recognition' => '1',
    'enable_email_notifications' => '0',
    'attendance_start_time' => '09:00',
    'attendance_end_time' => '18:00',
    'late_threshold_minutes' => '15',
    'timezone' => 'Asia/Kolkata',
    'theme' => 'light'
];

// Handle settings update
if (isset($_POST['save_settings'])) {
    foreach ($_POST as $key => $value) {
        if (array_key_exists($key, $default_settings)) {
            // Update or insert setting
            $value = mysqli_real_escape_string($conn, $value);
            $sql = "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) 
                    ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $key, $value);
            $stmt->execute();
        }
    }
    
    $_SESSION['message'] = "Settings updated successfully!";
    $_SESSION['message_type'] = "success";
}

// Get current settings
$settings = $default_settings;
$sql = "SELECT setting_key, setting_value FROM settings";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Face Attendance System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="static/modern-style.css">
    <script src="static/admin-menu.js" defer></script>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-user-shield"></i>
            <span>Admin Panel</span>
        </div>
        <ul class="sidebar-nav">
            <li class="sidebar-nav-item">
                <a href="admin_dashboard.php" class="sidebar-nav-link">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="employee_registration.php" class="sidebar-nav-link">
                    <i class="fas fa-user-plus"></i>
                    <span>Employee Registration</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="manage_employees.php" class="sidebar-nav-link">
                    <i class="fas fa-users"></i>
                    <span>Manage Employees</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="mark_attendance.php" class="sidebar-nav-link">
                    <i class="fas fa-calendar-check"></i>
                    <span>Mark Attendance</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="attendance_details.php" class="sidebar-nav-link">
                    <i class="fas fa-list"></i>
                    <span>Attendance Details</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="settings.php" class="sidebar-nav-link active">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li class="sidebar-nav-item">
                <a href="logout.php" class="sidebar-nav-link">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">System Settings</h1>
            <div class="d-flex align-items-center gap-3">
                <button class="dark-mode-toggle">
                    <i class="fas fa-moon"></i>
                </button>
                <div class="avatar">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=4C8BF5&color=fff" alt="Admin">
                </div>
            </div>
        </div>

        <?php if(isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['message']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php 
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
        endif; 
        ?>

        <div class="card">
            <div class="card-body">
                <form method="POST" class="needs-validation" novalidate>
                    <div class="row">
                        <!-- General Settings -->
                        <div class="col-md-6">
                            <h5 class="mb-4">General Settings</h5>
                            
                            <div class="mb-3">
                                <label class="form-label">System Name</label>
                                <input type="text" class="form-control" name="system_name" 
                                       value="<?php echo htmlspecialchars($settings['system_name']); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Company Name</label>
                                <input type="text" class="form-control" name="company_name" 
                                       value="<?php echo htmlspecialchars($settings['company_name']); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Timezone</label>
                                <select class="form-control" name="timezone">
                                    <?php
                                    $timezones = DateTimeZone::listIdentifiers();
                                    foreach ($timezones as $tz) {
                                        $selected = ($tz == $settings['timezone']) ? 'selected' : '';
                                        echo "<option value=\"$tz\" $selected>$tz</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Theme</label>
                                <select class="form-control" name="theme">
                                    <option value="light" <?php echo $settings['theme'] == 'light' ? 'selected' : ''; ?>>Light</option>
                                    <option value="dark" <?php echo $settings['theme'] == 'dark' ? 'selected' : ''; ?>>Dark</option>
                                </select>
                            </div>
                        </div>
                        
                        <!-- Attendance Settings -->
                        <div class="col-md-6">
                            <h5 class="mb-4">Attendance Settings</h5>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="enable_face_recognition" 
                                       name="enable_face_recognition" value="1" 
                                       <?php echo $settings['enable_face_recognition'] == '1' ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="enable_face_recognition">
                                    Enable Face Recognition
                                </label>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="enable_email_notifications" 
                                       name="enable_email_notifications" value="1" 
                                       <?php echo $settings['enable_email_notifications'] == '1' ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="enable_email_notifications">
                                    Enable Email Notifications
                                </label>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Attendance Start Time</label>
                                    <input type="time" class="form-control" name="attendance_start_time" 
                                           value="<?php echo $settings['attendance_start_time']; ?>" required>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Attendance End Time</label>
                                    <input type="time" class="form-control" name="attendance_end_time" 
                                           value="<?php echo $settings['attendance_end_time']; ?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Late Threshold (minutes)</label>
                                <input type="number" class="form-control" name="late_threshold_minutes" 
                                       value="<?php echo $settings['late_threshold_minutes']; ?>" 
                                       min="0" max="120" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-4 text-end">
                        <button type="reset" class="btn btn-secondary me-2">
                            <i class="fas fa-undo me-2"></i>Reset
                        </button>
                        <button type="submit" name="save_settings" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Save Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="mb-0">Database Management</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card border-0 bg-light">
                            <div class="card-body">
                                <h6 class="card-title">Backup Database</h6>
                                <p class="card-text text-muted">Create a backup of your entire database.</p>
                                <button class="btn btn-primary" onclick="alert('Backup functionality will be implemented in the future.')">
                                    <i class="fas fa-download me-2"></i>Backup Now
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card border-0 bg-light">
                            <div class="card-body">
                                <h6 class="card-title">Clear Attendance Data</h6>
                                <p class="card-text text-muted">Delete attendance records older than selected date.</p>
                                <div class="input-group">
                                    <input type="date" class="form-control" id="clear_date" 
                                           value="<?php echo date('Y-m-d', strtotime('-1 year')); ?>">
                                    <button class="btn btn-danger" onclick="confirmClear()">
                                        <i class="fas fa-trash me-2"></i>Clear Data
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        document.addEventListener('DOMContentLoaded', function() {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        form.classList.add('was-validated')
                    }, false)
                })

            // Dark mode toggle
            document.querySelector('.dark-mode-toggle').addEventListener('click', function() {
                document.body.classList.toggle('dark-mode');
            });
        });
        
        // Confirm data clearing
        function confirmClear() {
            const date = document.getElementById('clear_date').value;
            if (confirm(`Are you sure you want to delete all attendance records before ${date}? This action cannot be undone!`)) {
                alert('Data clearing functionality will be implemented in the future.');
            }
        }
    </script>
</body>
</html> 