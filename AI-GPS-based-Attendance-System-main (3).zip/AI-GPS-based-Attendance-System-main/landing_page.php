<?php
// Start session at the very beginning of the file
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AttendX - Employee Attendance System</title>
    <link rel="stylesheet" href="static/app-styles.css">
    <link rel="stylesheet" href="static/modern-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4C8BF5;
            --primary-hover: #3B73CC;
            --secondary-color: #3B73CC;
            --text-dark: #1C1C1C;
            --text-medium: #666666;
            --text-light: #AAAAAA;
            --bg-white: #ffffff;
            --bg-light: #F5F7FF;
            --gradient-primary: linear-gradient(135deg, #4C8BF5, #3B73CC);
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        .hero-section {
            background: var(--gradient-primary);
            padding: 150px 0 100px;
            color: white;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .hero-pattern {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB4PSIwIiB5PSIwIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSgzMCkiPjxyZWN0IHg9IjAiIHk9IjAiIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSI+PC9yZWN0PjwvcGF0dGVybj48L2RlZnM+PHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNwYXR0ZXJuKSI+PC9yZWN0Pjwvc3ZnPg==');
            opacity: 0.4;
        }

        .hero-content {
            position: relative;
            z-index: 10;
            max-width: 1000px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .hero-title {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            letter-spacing: -1px;
        }

        .hero-subtitle {
            font-size: 1.25rem;
            opacity: 0.9;
            margin-bottom: 40px;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
        }

        .hero-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-bottom: 60px;
        }

        .btn-hero {
            padding: 16px 32px;
            font-size: 1.1rem;
            font-weight: 500;
            border-radius: 50px;
            text-decoration: none;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-hero-primary {
            background-color: white;
            color: var(--primary-color);
            box-shadow: var(--shadow);
        }

        .btn-hero-primary:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg);
        }

        .btn-hero-secondary {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            backdrop-filter: blur(10px);
        }

        .btn-hero-secondary:hover {
            background-color: rgba(255, 255, 255, 0.3);
            transform: translateY(-3px);
        }

        .hero-image {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: var(--shadow-lg);
        }

        .features-section {
            padding: 100px 0;
            background-color: var(--bg-light);
        }

        .section-title {
            text-align: center;
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            color: var(--text-dark);
        }

        .section-subtitle {
            text-align: center;
            font-size: 1.1rem;
            color: var(--text-medium);
            margin-bottom: 60px;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .feature-card {
            background-color: white;
            border-radius: 10px;
            padding: 40px 30px;
            box-shadow: var(--shadow);
            transition: all 0.3s;
            text-align: center;
        }

        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
        }

        .feature-icon {
            height: 80px;
            width: 80px;
            background: var(--gradient-primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: white;
            font-size: 2rem;
        }

        .feature-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--text-dark);
        }

        .feature-description {
            color: var(--text-medium);
            line-height: 1.6;
        }

        .modules-section {
            padding: 100px 0;
            background-color: white;
        }

        .modules-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .module-card {
            background-color: var(--bg-light);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: all 0.3s;
        }

        .module-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
        }

        .module-image {
            height: 160px;
            background: var(--gradient-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
        }

        .module-content {
            padding: 25px;
        }

        .module-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--text-dark);
        }

        .module-description {
            color: var(--text-medium);
            font-size: 0.95rem;
            margin-bottom: 20px;
            line-height: 1.6;
        }

        .module-link {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: var(--primary-color);
            font-weight: 500;
            font-size: 0.95rem;
            gap: 5px;
            transition: all 0.2s;
        }

        .module-link:hover {
            gap: 8px;
            color: var(--primary-hover);
        }

        .footer {
            background-color: var(--text-dark);
            color: white;
            padding: 60px 0 30px;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
        }

        .footer-logo {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .footer-description {
            color: rgba(255, 255, 255, 0.7);
            margin-bottom: 25px;
            line-height: 1.6;
        }

        .footer-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 20px;
            color: white;
        }

        .footer-links {
            list-style: none;
            padding: 0;
        }

        .footer-links li {
            margin-bottom: 15px;
        }

        .footer-links a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-links a:hover {
            color: white;
        }

        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        .social-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
        }

        .social-icon:hover {
            background: var(--primary-color);
            transform: translateY(-3px);
        }

        .footer-bottom {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .copyright {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }
            .hero-buttons {
                flex-direction: column;
                gap: 15px;
            }
            .section-title {
                font-size: 2rem;
            }
            .footer-bottom {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="logo-container">
            <div class="logo">
                <div class="logo-icon">
                    <i class="fas fa-id-card"></i>
                </div>
                <span class="logo-text">AttendX</span>
            </div>
        </div>
        <nav class="nav-links">
            <a href="index.php?action=login" class="nav-link">
                <i class="fas fa-sign-in-alt"></i>
                <span>Login</span>
            </a>
            <a href="index.php?action=register" class="nav-link">
                <i class="fas fa-user-plus"></i>
                <span>Register</span>
            </a>
            <a href="#features" class="nav-link">
                <i class="fas fa-list-check"></i>
                <span>Features</span>
            </a>
            <a href="#modules" class="nav-link">
                <i class="fas fa-puzzle-piece"></i>
                <span>Modules</span>
            </a>
            <a href="#contact" class="nav-link">
                <i class="fas fa-envelope"></i>
                <span>Contact</span>
            </a>
        </nav>
    </header>

    <section class="hero-section">
        <div class="hero-pattern"></div>
        <div class="hero-content">
            <h1 class="hero-title">Modernize Your Attendance Management</h1>
            <p class="hero-subtitle">AttendX is a comprehensive employee attendance system that combines facial recognition technology with powerful analytics to streamline your attendance tracking process.</p>
            <div class="hero-buttons">
                <a href="index.php?action=login" class="btn-hero btn-hero-primary">
                    <i class="fas fa-sign-in-alt"></i> Sign In
                </a>
                <a href="index.php?action=register" class="btn-hero btn-hero-secondary">
                    <i class="fas fa-user-plus"></i> Register
                </a>
            </div>
            <img src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" alt="Employee Attendance System Dashboard" class="hero-image">
        </div>
    </section>

    <section class="features-section" id="features">
        <h2 class="section-title">Powerful Features</h2>
        <p class="section-subtitle">Discover what makes AttendX the perfect solution for your business attendance needs</p>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-camera"></i>
                </div>
                <h3 class="feature-title">Facial Recognition</h3>
                <p class="feature-description">Implement contactless attendance with our advanced facial recognition technology that ensures accurate employee identification.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <h3 class="feature-title">Real-time Tracking</h3>
                <p class="feature-description">Monitor attendance and time records in real-time with accurate timestamps to improve workforce management.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-chart-bar"></i>
                </div>
                <h3 class="feature-title">Analytics Dashboard</h3>
                <p class="feature-description">Gain insights with comprehensive analytics and reports to optimize productivity and resource allocation.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <h3 class="feature-title">Multi-device Support</h3>
                <p class="feature-description">Access the system from any device with our responsive design that works on desktop, tablet, and mobile.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-user-shield"></i>
                </div>
                <h3 class="feature-title">Role-based Access</h3>
                <p class="feature-description">Maintain security with role-based permissions for administrators and employees to access relevant features.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-bell"></i>
                </div>
                <h3 class="feature-title">Notifications</h3>
                <p class="feature-description">Stay informed with automatic notifications for late arrivals, absences, and other important attendance events.</p>
            </div>
        </div>
    </section>

    <section class="modules-section" id="modules">
        <h2 class="section-title">System Modules</h2>
        <p class="section-subtitle">Explore the key components of our attendance management system</p>
        
        <div class="modules-grid">
            <div class="module-card">
                <div class="module-image">
                    <i class="fas fa-user-circle"></i>
                </div>
                <div class="module-content">
                    <h3 class="module-title">Employee Portal</h3>
                    <p class="module-description">Employees can view their attendance records, request corrections, and manage their profiles.</p>
                    <a href="index.php?action=login&target=employee" class="module-link">Access Portal <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            
            <div class="module-card">
                <div class="module-image">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div class="module-content">
                    <h3 class="module-title">Admin Dashboard</h3>
                    <p class="module-description">Comprehensive administrative tools to manage employees, departments, and attendance policies.</p>
                    <a href="index.php?action=login&target=admin" class="module-link">Access Dashboard <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            
            <div class="module-card">
                <div class="module-image">
                    <i class="fas fa-camera"></i>
                </div>
                <div class="module-content">
                    <h3 class="module-title">Face Registration</h3>
                    <p class="module-description">Easy-to-use interface for capturing and registering employee facial data securely.</p>
                    <a href="index.php?action=register" class="module-link">Try Registration <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            
            <div class="module-card">
                <div class="module-image">
                    <i class="fas fa-clipboard-list"></i>
                </div>
                <div class="module-content">
                    <h3 class="module-title">Attendance Records</h3>
                    <p class="module-description">View, filter, and export detailed attendance records for reporting and analysis.</p>
                    <a href="index.php?action=login&target=attendance" class="module-link">View Records <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer" id="contact">
        <div class="footer-content">
            <div>
                <div class="footer-logo">
                    <i class="fas fa-id-card"></i>
                    <span>AttendX</span>
                </div>
                <p class="footer-description">A comprehensive employee attendance system with facial recognition technology for modern businesses.</p>
                <div class="social-links">
                    <a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            
            <div>
                <h3 class="footer-title">Quick Links</h3>
                <ul class="footer-links">
                    <li><a href="index.php?action=login"><i class="fas fa-angle-right"></i> Login</a></li>
                    <li><a href="index.php?action=register"><i class="fas fa-angle-right"></i> Register</a></li>
                    <li><a href="#features"><i class="fas fa-angle-right"></i> Features</a></li>
                    <li><a href="#modules"><i class="fas fa-angle-right"></i> Modules</a></li>
                    <li><a href="#contact"><i class="fas fa-angle-right"></i> Contact</a></li>
                </ul>
            </div>
            
            <div>
                <h3 class="footer-title">System Access</h3>
                <ul class="footer-links">
                    <li><a href="index.php?action=login"><i class="fas fa-sign-in-alt"></i> User Login</a></li>
                    <li><a href="index.php?action=login&target=admin"><i class="fas fa-user-shield"></i> Admin Dashboard</a></li>
                    <li><a href="index.php?action=login&target=employee"><i class="fas fa-user-circle"></i> Employee Portal</a></li>
                    <li><a href="index.php?action=login&target=attendance"><i class="fas fa-calendar-check"></i> Mark Attendance</a></li>
                    <li><a href="index.php?action=login&target=records"><i class="fas fa-clipboard-list"></i> Attendance Records</a></li>
                </ul>
            </div>
            
            <div>
                <h3 class="footer-title">Contact Us</h3>
                <ul class="footer-links">
                    <li><a href="#"><i class="fas fa-map-marker-alt"></i> 123 Business Avenue, Tech City</a></li>
                    <li><a href="mailto:info@attendx.com"><i class="fas fa-envelope"></i> info@attendx.com</a></li>
                    <li><a href="tel:+123456789"><i class="fas fa-phone"></i> +1 (234) 567-89</a></li>
                    <li><a href="#"><i class="fas fa-headset"></i> Support Center</a></li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p class="copyright">&copy; <?php echo date('Y'); ?> AttendX. All rights reserved.</p>
            <div>
                <a href="#" style="color: rgba(255,255,255,0.7); text-decoration: none; margin-left: 20px;">Privacy Policy</a>
                <a href="#" style="color: rgba(255,255,255,0.7); text-decoration: none; margin-left: 20px;">Terms of Service</a>
            </div>
        </div>
    </footer>

    <script>
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
        
        // Simple animation for features on scroll
        window.addEventListener('scroll', function() {
            const featureCards = document.querySelectorAll('.feature-card');
            featureCards.forEach(card => {
                const cardTop = card.getBoundingClientRect().top;
                if (cardTop < window.innerHeight - 100) {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }
            });
        });
        
        // Initialize cards with opacity 0 and transform
        document.addEventListener('DOMContentLoaded', function() {
            const featureCards = document.querySelectorAll('.feature-card');
            featureCards.forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(30px)';
                card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            });
            
            // Trigger the scroll event once to animate visible elements
            window.dispatchEvent(new Event('scroll'));
        });
    </script>
</body>
</html> 