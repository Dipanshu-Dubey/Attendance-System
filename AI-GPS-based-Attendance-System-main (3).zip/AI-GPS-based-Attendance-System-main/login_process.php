<?php
// Start session
session_start();

// Include database connection
include '__dbconnection.php';

// Check if the form was submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    // Validate data
    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "Email and password are required";
        header("Location: index.php?action=login");
        exit;
    }
    
    // Prepare SQL statement to prevent SQL injection
    $sql = "SELECT * FROM employees WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // For debugging - log user data
        error_log("User found: " . print_r($user, true));
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['logged_in'] = true;
            
            // Log role for debugging
            error_log("Login successful. Redirecting user with role: " . $user['role']);
            
            // Redirect based on role
            if ($user['role'] == 'Admin') {
                error_log("Redirecting to admin dashboard");
                // Use full URL path to ensure proper redirection
                $admin_url = "http://" . $_SERVER['HTTP_HOST'] . "/EMP_ATTENDANCE/admin_dashboard.php";
                error_log("Admin URL: $admin_url");
                header("Location: $admin_url");
                exit;
            } else if ($user['role'] == 'Employee') {
                error_log("Redirecting to employee dashboard");
                // Use full URL path to ensure proper redirection
                $employee_url = "http://" . $_SERVER['HTTP_HOST'] . "/EMP_ATTENDANCE/employee_dashboard.php";
                error_log("Employee URL: $employee_url");
                header("Location: $employee_url");
                exit;
            } else {
                $_SESSION['error'] = "Invalid user role";
                header("Location: index.php?action=login");
                exit;
            }
        } else {
            $_SESSION['error'] = "Incorrect password";
            header("Location: index.php?action=login");
            exit;
        }
    } else {
        $_SESSION['error'] = "User not found";
        header("Location: index.php?action=login");
        exit;
    }
} else {
    // If not a POST request, redirect to login page
    header("Location: index.php?action=login");
    exit;
}
?> 