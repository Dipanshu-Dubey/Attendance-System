<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: index.php?action=login");
    exit;
}

$login_email = $_SESSION['email'];
$login_name = $_SESSION['name'];
$user_role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Database connection
require '__dbconnection.php';

// Get matched employee name from URL
$matched_name = isset($_GET['matched_name']) ? $_GET['matched_name'] : '';
$face_matched = false;
$attendance_marked = false;
$identity_verified = false;

if ($matched_name != '') {
    // Fetch employee details using name
    $sql = "SELECT id, email, name FROM employees WHERE email = '$matched_name'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $emp_id = $row['id'];
        $email = $row['email'];
        $employee_name = $row['name'];
        $face_matched = true;
        
        // Verify if the recognized face belongs to the logged-in user
        $identity_verified = ($login_email == $matched_name);

        // Check if attendance is already marked for today
        $check_sql = "SELECT * FROM attendance WHERE id = '$user_id' AND DATE(timestamp) = CURDATE()";
        $check_result = mysqli_query($conn, $check_sql);

        if (mysqli_num_rows($check_result) == 0) {
            // Mark attendance as "Present" ONLY if the recognized face belongs to the logged-in user
            if($identity_verified) {
                $insert_sql = "INSERT INTO attendance (id, email, status) VALUES ('$user_id', '$login_email', 'Present')";
                if (mysqli_query($conn, $insert_sql)) {
                    $message = "Your attendance has been marked successfully!";
                    $status = "success";
                    $attendance_marked = true;
                } else {
                    $message = "Error marking attendance: " . mysqli_error($conn);
                    $status = "error";
                }
            } else {
                $message = "Face recognition detected a different person! You can only mark attendance with your own face.";
                $status = "warning";
            }
        } else {
            // Only show "already marked" if the identified face matches the user
            if ($identity_verified) {
                $message = "Your attendance has already been marked for today.";
                $status = "info";
                $attendance_marked = true;
            } else {
                $message = "Face recognition detected a different person! You can only mark attendance with your own face.";
                $status = "warning";
            }
        }
    } else {
        $message = "No matching employee found for this face.";
        $status = "error";
    }
} else {
    $message = "No face recognition data provided.";
    $status = "error";
}

// Close database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Result</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4C8BF5;
            --primary-hover: #3B73CC;
            --secondary-color: #3B73CC;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --error-color: #ef4444;
            --info-color: #3b82f6;
            --text-dark: #1C1C1C;
            --text-medium: #666666;
            --text-light: #AAAAAA;
            --bg-white: #ffffff;
            --bg-light: #F5F7FF;
            --bg-dark: #1C1C1C;
            --border-color: #CCCCCC;
            --box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --radius: 0.5rem;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            padding: 0;
        }

        .header {
            background-color: var(--bg-white);
            box-shadow: var(--box-shadow);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 700;
            font-size: 1.25rem;
            color: var(--primary-color);
        }

        .logo-icon {
            background: linear-gradient(135deg, #4C8BF5, #3B73CC);
            width: 2.5rem;
            height: 2.5rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-name {
            font-weight: 500;
        }

        .user-role {
            background-color: var(--primary-color);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: var(--bg-white);
            border-radius: var(--radius);
            box-shadow: var(--box-shadow);
            text-align: center;
        }

        .result-icon {
            font-size: 4rem;
            margin-bottom: 1.5rem;
        }

        .success .result-icon {
            color: var(--success-color);
        }

        .error .result-icon {
            color: var(--error-color);
        }

        .warning .result-icon {
            color: var(--warning-color);
        }

        .info .result-icon {
            color: var(--info-color);
        }

        h1 {
            margin-bottom: 0.5rem;
            font-size: 1.75rem;
        }

        .result-message {
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
            color: var(--text-medium);
        }

        .user-details {
            background-color: var(--bg-light);
            padding: 1.5rem;
            border-radius: var(--radius);
            margin: 1.5rem 0;
            text-align: left;
        }

        .detail-row {
            display: flex;
            margin-bottom: 0.75rem;
        }

        .detail-label {
            width: 150px;
            font-weight: 600;
            color: var(--text-medium);
        }

        .detail-value {
            flex: 1;
            color: var(--text-dark);
        }

        .button {
            display: inline-block;
            background: linear-gradient(135deg, #4C8BF5, #3B73CC);
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: var(--radius);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            margin-top: 1rem;
        }

        .button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(76, 139, 245, 0.3);
        }

        .timestamp {
            font-size: 0.875rem;
            color: var(--text-light);
            margin-top: 2rem;
        }

        .confetti {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            pointer-events: none;
        }

        .warning-message {
            color: var(--warning-color);
            font-weight: 600;
            background-color: rgba(245, 158, 11, 0.1);
            padding: 1rem;
            border-radius: var(--radius);
            border-left: 4px solid var(--warning-color);
            text-align: left;
            margin-bottom: 2rem;
        }
        
        .warning .result-icon {
            animation: pulse 1.5s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        /* Add special styling for identity mismatch alert */
        .identity-mismatch-alert {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--error-color);
            padding: 1.5rem;
            border-radius: var(--radius);
            margin: 1rem 0 2rem 0;
            text-align: left;
            font-weight: 600;
            border-left: 4px solid var(--error-color);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .identity-mismatch-alert i {
            margin-right: 0.5rem;
            font-size: 1.25rem;
        }
        
        /* Animation for error icon */
        .face-error .result-icon {
            animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both;
        }
        
        @keyframes shake {
            10%, 90% { transform: translate3d(-1px, 0, 0); }
            20%, 80% { transform: translate3d(2px, 0, 0); }
            30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
            40%, 60% { transform: translate3d(4px, 0, 0); }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">
            <div class="logo-icon">
                <i class="fas fa-id-card"></i>
            </div>
            <span>AttendX</span>
        </div>
        <div class="user-info">
            <span class="user-name"><?php echo htmlspecialchars($login_name); ?></span>
            <span class="user-role"><?php echo htmlspecialchars($user_role); ?></span>
        </div>
    </div>

    <div class="container <?php echo $status; ?> <?php echo (!$identity_verified && $face_matched) ? 'face-error' : ''; ?>">
        <?php if (!$identity_verified && $face_matched): ?>
            <div class="result-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h1>Identity Verification Failed</h1>
            
            <div class="identity-mismatch-alert">
                <i class="fas fa-user-shield"></i> 
                Security Alert: The face detected does not match your registered identity. 
                For security reasons, attendance can only be marked with your own face.
            </div>
            
        <?php elseif ($attendance_marked): ?>
            <div class="result-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h1>Attendance Marked Successfully!</h1>
        <?php elseif ($face_matched): ?>
            <div class="result-icon">
                <i class="fas fa-id-badge"></i>
            </div>
            <h1>Face Recognition Successful</h1>
        <?php else: ?>
            <div class="result-icon">
                <i class="fas fa-exclamation-circle"></i>
            </div>
            <h1>Face Recognition Result</h1>
        <?php endif; ?>

        <p class="result-message <?php echo $status === 'warning' ? 'warning-message' : ''; ?>"><?php echo htmlspecialchars($message); ?></p>

        <div class="user-details">
            <div class="detail-row">
                <div class="detail-label">Your Name:</div>
                <div class="detail-value"><?php echo htmlspecialchars($login_name); ?></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Your Email:</div>
                <div class="detail-value"><?php echo htmlspecialchars($login_email); ?></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Recognition Status:</div>
                <div class="detail-value">
                    <?php if ($face_matched && $identity_verified): ?>
                        <span style="color: var(--success-color); font-weight: 600;">
                            <i class="fas fa-user-check"></i> Your Face Recognized
                        </span>
                    <?php elseif ($face_matched && !$identity_verified): ?>
                        <span style="color: var(--error-color); font-weight: 600;">
                            <i class="fas fa-exclamation-triangle"></i> Different User's Face Detected
                        </span>
                    <?php else: ?>
                        <span style="color: var(--error-color); font-weight: 600;">
                            <i class="fas fa-user-times"></i> Unknown User
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Status:</div>
                <div class="detail-value">
                    <?php if ($attendance_marked): ?>
                        <span style="color: var(--success-color); font-weight: 600;">
                            <i class="fas fa-check-circle"></i> Attendance Marked
                        </span>
                    <?php elseif ($face_matched && !$identity_verified): ?>
                        <span style="color: var(--error-color); font-weight: 600;">
                            <i class="fas fa-exclamation-triangle"></i> Identity Verification Failed
                        </span>
                    <?php elseif ($face_matched): ?>
                        <span style="color: var(--info-color); font-weight: 600;">
                            <i class="fas fa-info-circle"></i> Face Recognized
                        </span>
                    <?php else: ?>
                        <span style="color: var(--error-color); font-weight: 600;">
                            <i class="fas fa-times-circle"></i> Not Recognized
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <a href="<?php echo $user_role === 'Admin' ? 'admin_dashboard.php' : 'employee_dashboard.php'; ?>" class="button">
            <i class="fas fa-home"></i> Back to Dashboard
        </a>

        <p class="timestamp">Time: <?php echo date('Y-m-d H:i:s'); ?></p>
    </div>

    <?php if ($attendance_marked): ?>
    <!-- Add confetti animation for successful attendance -->
    <canvas id="confetti" class="confetti"></canvas>
    <script>
        // Simple confetti animation
        const canvas = document.getElementById('confetti');
        const ctx = canvas.getContext('2d');
        const particles = [];
        const particleCount = 100;
        
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        function createParticles() {
            for (let i = 0; i < particleCount; i++) {
                particles.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height - canvas.height,
                    size: Math.random() * 5 + 1,
                    color: `hsl(${Math.random() * 360}, 100%, 50%)`,
                    speed: Math.random() * 5 + 1
                });
            }
        }
        
        function updateParticles() {
            for (let i = 0; i < particles.length; i++) {
                particles[i].y += particles[i].speed;
                
                if (particles[i].y > canvas.height) {
                    particles[i].y = -10;
                    particles[i].x = Math.random() * canvas.width;
                }
            }
        }
        
        function drawParticles() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            for (let i = 0; i < particles.length; i++) {
                ctx.fillStyle = particles[i].color;
                ctx.beginPath();
                ctx.arc(particles[i].x, particles[i].y, particles[i].size, 0, Math.PI * 2);
                ctx.closePath();
                ctx.fill();
            }
            
            updateParticles();
            requestAnimationFrame(drawParticles);
        }
        
        createParticles();
        drawParticles();
    </script>
    <?php endif; ?>
</body>
</html>
